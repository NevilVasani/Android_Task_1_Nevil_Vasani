package com.example.otpusingfirebase;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthMissingActivityForRecaptchaException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    EditText number;
    Button getOtp;
    ProgressBar progressBar;

//    String mVerificationId;
//    PhoneAuthProvider.ForceResendingToken mResendToken;
    FirebaseAuth mAuth;
//    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        number = findViewById(R.id.main_number);
        getOtp = findViewById(R.id.main_getotp);
        progressBar = findViewById(R.id.progressbar);

        getOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (number.getText().toString().isEmpty()) {
                    number.setError("Enter Mobile number");
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                getOtp.setVisibility(View.GONE);

                PhoneAuthProvider.getInstance().verifyPhoneNumber("+91" + number.getText().toString().trim(),
                        60, TimeUnit.SECONDS, MainActivity.this, new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                progressBar.setVisibility(View.GONE);
                                getOtp.setVisibility(View.VISIBLE);
                            }
                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                progressBar.setVisibility(View.VISIBLE);
                                getOtp.setVisibility(View.GONE);
                                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String verificationid, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
//                        super.onCodeSent(s, forceResendingToken);
                                progressBar.setVisibility(View.GONE);
                                getOtp.setVisibility(View.VISIBLE);
                                Intent intent = new Intent(MainActivity.this, VerifyPhoneActivity.class);
                                intent.putExtra("mobile",number.getText().toString());
                                intent.putExtra("verificationid",verificationid);
                                startActivity(intent);
                            }
                        });
            }
        });

    }
}



